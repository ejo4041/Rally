import {createLivingSilk,mountLivingSilkControls} from '../src/index';
import '../src/controls.css';

export function mountMeetingPresence(surface:HTMLElement,controlsHost:HTMLElement){
 const silk=createLivingSilk(surface,{quality:'auto'});
 const controls=mountLivingSilkControls(controlsHost,silk);
 return {
  silk,
  setMeetingFeeling: (feeling:Parameters<typeof silk.setEmotion>[0])=>silk.setEmotion(feeling),
  dispose: async()=>{controls.dispose();await silk.dispose()},
 };
}
