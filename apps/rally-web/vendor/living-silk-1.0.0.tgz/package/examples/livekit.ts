import {RoomEvent,Track,type Room,type RemoteParticipant,type RemoteTrack,type RemoteTrackPublication} from 'livekit-client';
import type {LivingSilk} from '../src/index';

/** Call from a user gesture after the room has joined. Playback stays with the host app. */
export function bindBotAudio(room:Room,silk:LivingSilk,botIdentity:string,onError:(error:unknown)=>void){
 let disposed=false;
 let active:RemoteTrack|null=null;
 const candidates=new Map<string,RemoteTrack>();
 function choose(){
  const next=Array.from(candidates.values()).find(track=>track.mediaStreamTrack.readyState==='live')??null;
  if(next===active)return;active=next;
  if(next)void silk.connectBotTrack(next.mediaStreamTrack).catch(error=>{if(!disposed)onError(error)});
  else silk.disconnectBotAudio();
 }
 function subscribed(track:RemoteTrack,publication:RemoteTrackPublication,participant:RemoteParticipant){
  if(participant.identity!==botIdentity||track.kind!==Track.Kind.Audio)return;
  candidates.set(publication.trackSid,track);choose();
 }
 function unsubscribed(track:RemoteTrack,publication:RemoteTrackPublication){
  if(candidates.get(publication.trackSid)===track){candidates.delete(publication.trackSid);choose()}
 }
 function disconnected(){candidates.clear();active=null;silk.disconnectBotAudio()}
 room.on(RoomEvent.TrackSubscribed,subscribed);room.on(RoomEvent.TrackUnsubscribed,unsubscribed);room.on(RoomEvent.Disconnected,disconnected);
 for(const participant of room.remoteParticipants.values())for(const publication of participant.trackPublications.values())if(publication.track)subscribed(publication.track,publication,participant);
 return ()=>{if(disposed)return;disposed=true;room.off(RoomEvent.TrackSubscribed,subscribed);room.off(RoomEvent.TrackUnsubscribed,unsubscribed);room.off(RoomEvent.Disconnected,disconnected);candidates.clear();active=null;silk.disconnectBotAudio()};
}
