# Living Silk

A framework-free, expressive WebGL visualization with optional native DOM controls. Emotion, speech and adaptive rendering are independent inputs. There is no viewer, application shell, router, backend, telemetry, storage, external asset request or authentication logic.

The renderer uses **Three.js 0.180.0**, not a UI framework. It preserves the silk material, crisp motes, continuous emotion blends, Sass and the calmer speaking motion. WebGL2 and modern browser media APIs are required.

## Drop into an application

Install this folder as a local dependency:

```sh
npm install ./vendor/living-silk
```

Then use the normal esbuild entry point:

```ts
import {createLivingSilk, mountLivingSilkControls} from 'living-silk';
import 'living-silk/controls.css'; // Optional; scoped to the controls only.

const surface = document.querySelector<HTMLElement>('#meeting-presence')!;
const controlsHost = document.querySelector<HTMLElement>('#presence-controls')!;
const silk = createLivingSilk(surface, {quality: 'auto'});
const controls = mountLivingSilkControls(controlsHost, silk);

silk.setEmotion({joy: .55, confidence: .8, sass: .2});
silk.setTuning({articulation: 1, particles: 1});

// When the containing screen is removed:
controls.dispose();
await silk.dispose();
```

Give the visualization container an explicit size. The component appends one canvas and leaves the host element and its other children alone.

```css
#meeting-presence { width: 100%; height: 240px; }
@media (max-width: 600px) { #meeting-presence { height: 180px; } }
```

Use `examples/embed.ts` as a native DOM mounting pattern. Or copy `src/` into the application and install `three@0.180.0`. No React, R3F, Vue, Next.js, Vite, Tailwind or component library is required.

`dist/index.js` is ESM with Three.js external so the host bundler can share/tree-shake it. `dist/living-silk.browser.js` is a standalone ESM bundle with Three.js included; it can be served directly without a bundler. Type declarations and scoped controls CSS are included. Source maps are deliberately omitted.

## Control API

| Method | Purpose |
|---|---|
| `setEmotion(partial)` | Merge continuous targets in the range 0–1: joy, curiosity, worry, irritation, sadness, confidence, energy, sass, expressiveness. |
| `getEmotion()` | Read a copy of the current targets. |
| `setTuning(partial)` | Set strands, particles, attachment and articulation in the range 0–2. Defaults are1. |
| `setQuality(mode)` | `auto`, `full`, `balanced` or `economy`. Auto starts at full. |
| `intervene()` | Play a bounded attention gesture. |
| `enableAudio()` | Resume the analysis context from a user gesture before remote bot audio arrives. |
| `connectBotTrack(track)` | Analyze a borrowed bot `MediaStreamTrack`. Returns a promise. |
| `disconnectBotAudio()` | Disconnect analysis and let speech motion settle. |
| `setVoice(frame)` | Supply already-computed bot audio features; disconnects track analysis. |
| `pause()` / `resume()` | Explicitly suspend/resume rendering. |
| `getMetrics()` | Read recent frame rate, CPU submission time, geometry and drawing-buffer counts. Returns null before the first sample. |
| `dispose()` | Idempotently remove the canvas, listeners, observers and graphics/audio resources. Returns a promise. |

The optional controls stay synchronized with programmatic emotion/tuning/quality changes. They do not request a microphone or provide a media player. Disable sections with `{emotion:false, material:false, quality:false, intervention:false}`. Disposal of the visualization also removes its mounted controls.

## LiveKit bot audio

Use the application's existing LiveKit 2.23.0 installation. `examples/livekit.ts` is a typed adapter that handles existing subscriptions, replacement and unsubscribe/disconnect cleanup. It filters by an explicit bot participant identity and audio kind. It does not subscribe to additional tracks, attach playback elements, publish tracks or process other participants' audio.

Enable analysis alongside the application's normal audio-unlock action:

```ts
// In the application's join/unmute button handler:
await Promise.all([silk.enableAudio(), room.startAudio()]);
const unbind = bindBotAudio(room, silk, botIdentity, console.error);

// Screen teardown, before silk.dispose():
unbind();
```

Import `bindBotAudio` from a copied `examples/livekit.ts` module and adjust its relative Living Silk import to your package location. Alternatively, call `silk.connectBotTrack(remoteAudioTrack.mediaStreamTrack)` in existing room event handlers. The adapter was type-checked against LiveKit 2.23.0; a connected LiveKit room is not needed by the renderer itself.

The component neither plays nor stops borrowed tracks. Its analysis graph uses a zero-gain output, so playback remains solely with the host application. No microphone permission is requested automatically. Connecting or enabling audio may require a user gesture because of browser autoplay rules. If several bot audio publications exist, the example selects the first live candidate; narrow its filter if the application needs a particular source.

## Existing audio-feature pipeline

`setVoice()` accepts a `BotVoiceFrame`:

```ts
silk.setVoice({
  level: .5,
  phrase: .45,
  bands: [.4, .3, .25, .1, .05],
  timestamp: performance.now() / 1000,
  sourceEpoch: 1,
});
```

All amplitudes are normalized 0–1. The five bands are 80–250,250–600,600–1500,1500–3500 and3500–8000Hz. `timestamp` is the current browser's monotonic time in **seconds**, not a Unix timestamp. Increment `sourceEpoch` on source replacement. Send fresh frames while the bot speaks, then a zero-valued frame; stale frames decay automatically. Only bot output should enter this path. Meeting assessment updates emotion separately.

## Rendering and video output

Resize is automatic. Offscreen/hidden rendering pauses by default. `background:'transparent'` removes the atmospheric backdrop. For an intentionally offscreen canvas, `visibility:'always'` bypasses this component's visibility gate; browsers can still throttle background tabs.

The public `silk.canvas` can be passed to `captureStream()` for a host-managed LiveKit video track. The host owns captured tracks and their cleanup. Background browser throttling means this is not a guaranteed server-side video renderer.

Adaptive quality changes mesh detail and drawing-buffer resolution after sustained slow frames, and restores a reduction if it does not help. It preserves motion, emotion and mote population. Full quality remains available explicitly. CPU submission metrics are not GPU execution timings.

Handle unavailable/lost graphics in the host application: construction throws if WebGL2 cannot initialize, and `onError(error)` reports rendering/context errors. Context restoration resumes automatically when the browser restores the context. An uncaught application metrics-callback error pauses rendering and is reported through `onError`.

## Build and verify

Node 24+, esbuild 0.28.2 and TypeScript 7.0.2 are pinned in this package. The runtime dependency is Three.js; LiveKit and Playwright are development-only checks/examples.

```sh
npm ci
npm run typecheck
npm run build
npm test
npx playwright install chromium
npm run test:browser
```

The test fixture is development-only and is not part of the runtime entry point. Node tests cover motion continuity, adaptive quality and borrowed-track lifecycle. Browser tests cover actual WebGL construction, controls, resize, audio connection and disposal. A real LiveKit session and low-power physical devices still need application-level testing.

The component requires no Express, SQLite, cookie-authentication or API changes. Feed it the application's existing shared contracts through `setEmotion()` and its bot media/features through the audio API.

## Distribution

The deliverable contains no personal author fields, deployment configuration, internal domains, machine paths, audio recordings, source maps, development logs or computer metadata. Runtime code performs no network requests. Required third-party license notices are retained in `THIRD_PARTY_NOTICES.txt` and in the standalone bundle. They are not attribution to the application owner.
