import {createServer} from 'node:http';
import {readFile} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
createServer(async(request,response)=>{try{const pathname=new URL(request.url,'http://127.0.0.1').pathname;const file=path.resolve(root,'.'+decodeURIComponent(pathname));if(!file.startsWith(root+path.sep))throw Error('Invalid path');const data=await readFile(file);response.setHeader('Content-Type',file.endsWith('.html')?'text/html':file.endsWith('.css')?'text/css':'text/javascript');response.end(data)}catch{response.writeHead(404);response.end('Not found')}}).listen(4174,'127.0.0.1');
