import test from 'node:test';
import assert from 'node:assert/strict';
import {build} from 'esbuild';
async function load(file){const result=await build({entryPoints:[`src/${file}.ts`],bundle:true,write:false,format:'esm',platform:'node',target:'es2022'});return import(`data:text/javascript;base64,${Buffer.from(result.outputFiles[0].text).toString('base64')}`)}
const {HarmonicDriver}=await load('driver');
const {AdaptiveQualityController,deriveQuality}=await load('quality');
const {BotAudioInput}=await load('bot-audio');
test('continuous motion agrees at 30, 60 and 120 Hz and stale speech settles',()=>{
 const runs=[30,60,120].map(hz=>{const d=new HarmonicDriver({joy:0});d.advance(0);d.setEmotion({joy:.9,worry:.4,sass:.8});for(let i=1;i<=hz*3;i++){const time=i/hz;d.setVoice({level:.6,phrase:.6,bands:[.4,.3,.2,.1,.1],timestamp:time,sourceEpoch:1});d.advance(time)}return d});
 const referencePhase=runs[0].frame.phase,referenceJoy=runs[0].frame.emotion.joy;
 for(const d of runs){assert.ok(Math.abs(d.frame.phase-referencePhase)<1e-8);assert.ok(Math.abs(d.frame.emotion.joy-referenceJoy)<1e-8);assert.ok([...d.frame.history].every(Number.isFinite));for(let i=1;i<=600;i++)d.advance(3+i/60);assert.ok(d.frame.voice.level<1e-8)}
});
test('quality preserves fast displays and restores ineffective capped-frame trials',()=>{
 for(const hz of [30,60,90,120]){const q=new AdaptiveQualityController();for(let t=0;t<40000;t+=1000/hz)q.sample({now:t,frameMs:1000/hz});assert.equal(q.tier,'full')}
 const q=new AdaptiveQualityController();let now=0;for(;now<25000;){const ms=q.tier==='full'?34:18;now+=ms;q.sample({now,frameMs:ms})}assert.equal(q.tier,'balanced');for(;now<100000;now+=8.33)q.sample({now,frameMs:8.33});assert.equal(q.tier,'full');
 const full=deriveQuality('full',180,2),eco=deriveQuality('economy',180,2);assert.ok(eco.segmentsX*eco.segmentsY<full.segmentsX*full.segmentsY);assert.ok(eco.dpr<full.dpr);
});
test('bot analysis borrows tracks, uses a silent sink and cancels pending connections',async()=>{
 const oldContext=globalThis.AudioContext,oldStream=globalThis.MediaStream;
 const contexts=[];
 class Node {connections=[];gain={value:1};connect(node){this.connections.push(node)}disconnect(){this.connections=[]}}
 class Context {state='running';sampleRate=48000;destination=new Node();closed=0;nodes=[];pending=null;constructor(){contexts.push(this)}resume(){return this.pending??Promise.resolve()}createAnalyser(){const n=new Node();n.getFloatTimeDomainData=a=>a.fill(.04);n.getFloatFrequencyData=a=>a.fill(-60);this.nodes.push(n);return n}createMediaStreamSource(){const n=new Node();this.nodes.push(n);return n}createGain(){const n=new Node();this.nodes.push(n);return n}close(){this.closed++;this.state='closed';return Promise.resolve()}}
 class Track extends EventTarget {kind='audio';readyState='live';enabled=true;muted=false;stops=0;stop(){this.stops++}}
 globalThis.AudioContext=Context;globalThis.MediaStream=class {constructor(tracks){this.tracks=tracks}};
 try{const input=new BotAudioInput(),track=new Track();await input.connect(track);assert.equal(track.stops,0);assert.equal(contexts[0].nodes.at(-1).gain.value,0);assert.ok(input.sample(1).level>0);input.disconnect();assert.equal(input.connected,false);assert.equal(track.readyState,'live');let release;contexts[0].pending=new Promise(r=>{release=r});const pending=input.connect(track);input.disconnect();release();await pending;assert.equal(input.connected,false);await input.dispose();await input.dispose();assert.equal(contexts[0].closed,1);assert.equal(track.stops,0)}finally{globalThis.AudioContext=oldContext;globalThis.MediaStream=oldStream}
});
